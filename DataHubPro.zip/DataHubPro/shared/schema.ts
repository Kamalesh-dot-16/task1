import {
  pgTable,
  text,
  varchar,
  timestamp,
  jsonb,
  index,
  serial,
  boolean,
  integer,
  decimal
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { relations } from "drizzle-orm";

// Session storage table (required for Replit Auth)
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// User storage table (required for Replit Auth)
export const users = pgTable("users", {
  id: varchar("id").primaryKey().notNull(),
  email: varchar("email").unique(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"),
  role: varchar("role").notNull().default("user"),
  isActive: boolean("is_active").notNull().default(true),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Roles table
export const roles = pgTable("roles", {
  id: serial("id").primaryKey(),
  name: varchar("name").notNull().unique(),
  description: text("description"),
  permissions: jsonb("permissions").notNull().default("[]"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Datasets table
export const datasets = pgTable("datasets", {
  id: serial("id").primaryKey(),
  name: varchar("name").notNull(),
  description: text("description"),
  category: varchar("category").notNull(), // text, image, video
  fileName: varchar("file_name").notNull(),
  fileSize: integer("file_size").notNull(),
  fileType: varchar("file_type").notNull(), // MIME type: text/csv, image/jpeg, video/mp4, etc.
  filePath: varchar("file_path"), // Cloud storage path (Azure BLOB/S3)
  thumbnailPath: varchar("thumbnail_path"), // For images/videos
  duration: integer("duration"), // For videos (in seconds)
  dimensions: jsonb("dimensions"), // For images/videos: {width: number, height: number}
  metadata: jsonb("metadata"), // Additional file-specific metadata
  status: varchar("status").notNull().default("uploaded"),
  uploadedBy: varchar("uploaded_by").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Processing jobs table
export const processingJobs = pgTable("processing_jobs", {
  id: serial("id").primaryKey(),
  datasetId: integer("dataset_id").notNull(),
  jobType: varchar("job_type").notNull(),
  status: varchar("status").notNull().default("pending"),
  progress: integer("progress").notNull().default(0),
  result: jsonb("result"),
  errorMessage: text("error_message"),
  startedAt: timestamp("started_at"),
  completedAt: timestamp("completed_at"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Insights table
export const insights = pgTable("insights", {
  id: serial("id").primaryKey(),
  datasetId: integer("dataset_id").notNull(),
  title: varchar("title").notNull(),
  description: text("description"),
  insightType: varchar("insight_type").notNull(),
  data: jsonb("data").notNull(),
  confidence: decimal("confidence", { precision: 5, scale: 2 }),
  generatedBy: varchar("generated_by").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

// Reports table
export const reports = pgTable("reports", {
  id: serial("id").primaryKey(),
  name: varchar("name").notNull(),
  description: text("description"),
  reportType: varchar("report_type").notNull(),
  datasetIds: jsonb("dataset_ids").notNull(),
  parameters: jsonb("parameters"),
  generatedBy: varchar("generated_by").notNull(),
  filePath: varchar("file_path"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Notifications table
export const notifications = pgTable("notifications", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull(),
  title: varchar("title").notNull(),
  message: text("message").notNull(),
  type: varchar("type").notNull().default("info"),
  isRead: boolean("is_read").notNull().default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

// Activity logs table
export const activityLogs = pgTable("activity_logs", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull(),
  action: varchar("action").notNull(),
  resource: varchar("resource"),
  resourceId: integer("resource_id"),
  metadata: jsonb("metadata"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Relations
export const usersRelations = relations(users, ({ many }) => ({
  datasets: many(datasets),
  insights: many(insights),
  reports: many(reports),
  notifications: many(notifications),
  activityLogs: many(activityLogs),
}));

export const datasetsRelations = relations(datasets, ({ one, many }) => ({
  uploader: one(users, {
    fields: [datasets.uploadedBy],
    references: [users.id],
  }),
  processingJobs: many(processingJobs),
  insights: many(insights),
}));

export const processingJobsRelations = relations(processingJobs, ({ one }) => ({
  dataset: one(datasets, {
    fields: [processingJobs.datasetId],
    references: [datasets.id],
  }),
}));

export const insightsRelations = relations(insights, ({ one }) => ({
  dataset: one(datasets, {
    fields: [insights.datasetId],
    references: [datasets.id],
  }),
  generator: one(users, {
    fields: [insights.generatedBy],
    references: [users.id],
  }),
}));

export const reportsRelations = relations(reports, ({ one }) => ({
  generator: one(users, {
    fields: [reports.generatedBy],
    references: [users.id],
  }),
}));

export const notificationsRelations = relations(notifications, ({ one }) => ({
  user: one(users, {
    fields: [notifications.userId],
    references: [users.id],
  }),
}));

export const activityLogsRelations = relations(activityLogs, ({ one }) => ({
  user: one(users, {
    fields: [activityLogs.userId],
    references: [users.id],
  }),
}));

// Export types
export type UpsertUser = typeof users.$inferInsert;
export type User = typeof users.$inferSelect;

export type Role = typeof roles.$inferSelect;
export type InsertRole = typeof roles.$inferInsert;
export const insertRoleSchema = createInsertSchema(roles);

export type Dataset = typeof datasets.$inferSelect;
export type InsertDataset = typeof datasets.$inferInsert;
export const insertDatasetSchema = createInsertSchema(datasets);

export type ProcessingJob = typeof processingJobs.$inferSelect;
export type InsertProcessingJob = typeof processingJobs.$inferInsert;
export const insertProcessingJobSchema = createInsertSchema(processingJobs);

export type Insight = typeof insights.$inferSelect;
export type InsertInsight = typeof insights.$inferInsert;
export const insertInsightSchema = createInsertSchema(insights);

export type Report = typeof reports.$inferSelect;
export type InsertReport = typeof reports.$inferInsert;
export const insertReportSchema = createInsertSchema(reports);

export type Notification = typeof notifications.$inferSelect;
export type InsertNotification = typeof notifications.$inferInsert;
export const insertNotificationSchema = createInsertSchema(notifications);

export type ActivityLog = typeof activityLogs.$inferSelect;
export type InsertActivityLog = typeof activityLogs.$inferInsert;
export const insertActivityLogSchema = createInsertSchema(activityLogs);
