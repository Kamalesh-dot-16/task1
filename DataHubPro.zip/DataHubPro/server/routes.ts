import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import { insertDatasetSchema, insertReportSchema, insertNotificationSchema, insertActivityLogSchema } from "@shared/schema";
import multer from "multer";
import path from "path";
import fs from "fs";

const upload = multer({
  dest: "uploads/",
  limits: { fileSize: 100 * 1024 * 1024 }, // 100MB limit
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth middleware
  await setupAuth(app);

  // Auth routes
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Dashboard routes
  app.get('/api/dashboard/metrics', isAuthenticated, async (req, res) => {
    try {
      const metrics = await storage.getDashboardMetrics();
      res.json(metrics);
    } catch (error) {
      console.error("Error fetching dashboard metrics:", error);
      res.status(500).json({ message: "Failed to fetch dashboard metrics" });
    }
  });

  app.get('/api/dashboard/recent-activity', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const activities = await storage.getUserActivityLogs(userId);
      res.json(activities);
    } catch (error) {
      console.error("Error fetching recent activity:", error);
      res.status(500).json({ message: "Failed to fetch recent activity" });
    }
  });

  // Dataset routes
  app.get('/api/datasets', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      let datasets;
      if (user?.role === 'admin') {
        datasets = await storage.getAllDatasets();
      } else {
        datasets = await storage.getDatasetsByUser(userId);
      }
      
      res.json(datasets);
    } catch (error) {
      console.error("Error fetching datasets:", error);
      res.status(500).json({ message: "Failed to fetch datasets" });
    }
  });

  app.post('/api/datasets', isAuthenticated, upload.single('file'), async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const file = req.file;
      
      if (!file) {
        return res.status(400).json({ message: "No file uploaded" });
      }

      const datasetData = insertDatasetSchema.parse({
        name: req.body.name,
        description: req.body.description,
        category: req.body.category,
        fileName: file.originalname,
        fileSize: file.size,
        fileType: file.mimetype,
        uploadedBy: userId,
      });

      const dataset = await storage.createDataset(datasetData);

      // Log activity
      await storage.createActivityLog({
        userId,
        action: "upload_dataset",
        resource: "dataset",
        resourceId: dataset.id,
        metadata: { fileName: file.originalname, fileSize: file.size },
      });

      // Create notification
      await storage.createNotification({
        userId,
        title: "Dataset uploaded",
        message: `Your dataset "${dataset.name}" has been uploaded successfully`,
        type: "success",
      });

      res.json(dataset);
    } catch (error) {
      console.error("Error uploading dataset:", error);
      res.status(500).json({ message: "Failed to upload dataset" });
    }
  });

  app.delete('/api/datasets/:id', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const datasetId = parseInt(req.params.id);
      
      await storage.deleteDataset(datasetId);
      
      // Log activity
      await storage.createActivityLog({
        userId,
        action: "delete_dataset",
        resource: "dataset",
        resourceId: datasetId,
      });

      res.json({ message: "Dataset deleted successfully" });
    } catch (error) {
      console.error("Error deleting dataset:", error);
      res.status(500).json({ message: "Failed to delete dataset" });
    }
  });

  // Processing job routes
  app.get('/api/processing-jobs', isAuthenticated, async (req, res) => {
    try {
      const jobs = await storage.getAllProcessingJobs();
      res.json(jobs);
    } catch (error) {
      console.error("Error fetching processing jobs:", error);
      res.status(500).json({ message: "Failed to fetch processing jobs" });
    }
  });

  app.post('/api/processing-jobs', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const jobData = {
        datasetId: req.body.datasetId,
        jobType: req.body.jobType,
        status: "pending",
      };

      const job = await storage.createProcessingJob(jobData);

      // Simulate processing (in a real app, this would be queued)
      setTimeout(async () => {
        try {
          await storage.updateProcessingJob(job.id, {
            status: "running",
            progress: 50,
            startedAt: new Date(),
          });

          // Simulate completion
          setTimeout(async () => {
            await storage.updateProcessingJob(job.id, {
              status: "completed",
              progress: 100,
              completedAt: new Date(),
              result: { processed: true, recordCount: Math.floor(Math.random() * 10000) },
            });

            // Create insight based on processing
            await storage.createInsight({
              datasetId: job.datasetId,
              title: "Processing Complete",
              description: "Data processing completed successfully with insights generated",
              insightType: "processing_result",
              data: { status: "completed", jobId: job.id },
              confidence: "95.5",
              generatedBy: userId,
            });

            // Create notification
            await storage.createNotification({
              userId,
              title: "Processing completed",
              message: "Your data processing job has completed successfully",
              type: "success",
            });
          }, 3000);
        } catch (error) {
          console.error("Error in simulated processing:", error);
        }
      }, 1000);

      res.json(job);
    } catch (error) {
      console.error("Error creating processing job:", error);
      res.status(500).json({ message: "Failed to create processing job" });
    }
  });

  // Insights routes
  app.get('/api/insights', isAuthenticated, async (req, res) => {
    try {
      const insights = await storage.getAllInsights();
      res.json(insights);
    } catch (error) {
      console.error("Error fetching insights:", error);
      res.status(500).json({ message: "Failed to fetch insights" });
    }
  });

  app.get('/api/insights/dataset/:id', isAuthenticated, async (req, res) => {
    try {
      const datasetId = parseInt(req.params.id);
      const insights = await storage.getInsightsByDataset(datasetId);
      res.json(insights);
    } catch (error) {
      console.error("Error fetching dataset insights:", error);
      res.status(500).json({ message: "Failed to fetch dataset insights" });
    }
  });

  // Reports routes
  app.get('/api/reports', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      let reports;
      if (user?.role === 'admin') {
        reports = await storage.getAllReports();
      } else {
        reports = await storage.getReportsByUser(userId);
      }
      
      res.json(reports);
    } catch (error) {
      console.error("Error fetching reports:", error);
      res.status(500).json({ message: "Failed to fetch reports" });
    }
  });

  app.post('/api/reports', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      
      const reportData = insertReportSchema.parse({
        name: req.body.name,
        description: req.body.description,
        reportType: req.body.reportType,
        datasetIds: req.body.datasetIds,
        parameters: req.body.parameters,
        generatedBy: userId,
      });

      const report = await storage.createReport(reportData);

      // Log activity
      await storage.createActivityLog({
        userId,
        action: "generate_report",
        resource: "report",
        resourceId: report.id,
        metadata: { reportType: report.reportType },
      });

      res.json(report);
    } catch (error) {
      console.error("Error generating report:", error);
      res.status(500).json({ message: "Failed to generate report" });
    }
  });

  // Notification routes
  app.get('/api/notifications', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const notifications = await storage.getUserNotifications(userId);
      res.json(notifications);
    } catch (error) {
      console.error("Error fetching notifications:", error);
      res.status(500).json({ message: "Failed to fetch notifications" });
    }
  });

  app.patch('/api/notifications/:id/read', isAuthenticated, async (req, res) => {
    try {
      const notificationId = parseInt(req.params.id);
      await storage.markNotificationAsRead(notificationId);
      res.json({ message: "Notification marked as read" });
    } catch (error) {
      console.error("Error marking notification as read:", error);
      res.status(500).json({ message: "Failed to mark notification as read" });
    }
  });

  app.get('/api/notifications/unread-count', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const count = await storage.getUnreadNotificationCount(userId);
      res.json({ count });
    } catch (error) {
      console.error("Error fetching unread notification count:", error);
      res.status(500).json({ message: "Failed to fetch unread count" });
    }
  });

  // User management routes (admin only)
  app.get('/api/users', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      if (user?.role !== 'admin') {
        return res.status(403).json({ message: "Admin access required" });
      }
      
      const users = await storage.getAllUsers();
      res.json(users);
    } catch (error) {
      console.error("Error fetching users:", error);
      res.status(500).json({ message: "Failed to fetch users" });
    }
  });

  app.patch('/api/users/:id/role', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      if (user?.role !== 'admin') {
        return res.status(403).json({ message: "Admin access required" });
      }

      const targetUserId = req.params.id;
      const newRole = req.body.role;
      
      await storage.updateUserRole(targetUserId, newRole);
      
      // Log activity
      await storage.createActivityLog({
        userId,
        action: "update_user_role",
        resource: "user",
        metadata: { targetUserId, newRole },
      });

      res.json({ message: "User role updated successfully" });
    } catch (error) {
      console.error("Error updating user role:", error);
      res.status(500).json({ message: "Failed to update user role" });
    }
  });

  app.patch('/api/users/:id/status', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      if (user?.role !== 'admin') {
        return res.status(403).json({ message: "Admin access required" });
      }

      const targetUserId = req.params.id;
      const isActive = req.body.isActive;
      
      await storage.updateUserStatus(targetUserId, isActive);
      
      // Log activity
      await storage.createActivityLog({
        userId,
        action: "update_user_status",
        resource: "user",
        metadata: { targetUserId, isActive },
      });

      res.json({ message: "User status updated successfully" });
    } catch (error) {
      console.error("Error updating user status:", error);
      res.status(500).json({ message: "Failed to update user status" });
    }
  });

  // Role management routes (admin only)
  app.get('/api/roles', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      if (user?.role !== 'admin') {
        return res.status(403).json({ message: "Admin access required" });
      }
      
      const roles = await storage.getAllRoles();
      res.json(roles);
    } catch (error) {
      console.error("Error fetching roles:", error);
      res.status(500).json({ message: "Failed to fetch roles" });
    }
  });

  app.post('/api/roles', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      if (user?.role !== 'admin') {
        return res.status(403).json({ message: "Admin access required" });
      }

      const roleData = {
        name: req.body.name,
        description: req.body.description,
        permissions: req.body.permissions || [],
      };

      const role = await storage.createRole(roleData);
      res.json(role);
    } catch (error) {
      console.error("Error creating role:", error);
      res.status(500).json({ message: "Failed to create role" });
    }
  });

  // Profile routes
  app.get('/api/profile', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Add access settings (default to true for most features)
      const profileData = {
        ...user,
        accessSettings: {
          canViewDashboard: true,
          canUploadData: true,
          canProcessData: true,
          canViewInsights: true,
          canGenerateReports: true,
          canViewHistory: true,
          canManageUsers: user.role === 'admin',
          canManageRoles: user.role === 'admin',
        }
      };
      
      res.json(profileData);
    } catch (error) {
      console.error("Error fetching profile:", error);
      res.status(500).json({ message: "Failed to fetch profile" });
    }
  });

  app.put('/api/profile/personal', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { firstName, lastName, email } = req.body;
      
      // Validate required fields
      if (!firstName || !lastName || !email) {
        return res.status(400).json({ message: "First name, last name, and email are required" });
      }
      
      // Check if email is already taken by another user
      const existingUser = await storage.getUserByEmail(email);
      if (existingUser && existingUser.id !== userId) {
        return res.status(409).json({ message: "Email already in use by another account" });
      }
      
      // Update user profile
      const updatedUser = await storage.updateUser(userId, {
        firstName,
        lastName,
        email,
        updatedAt: new Date(),
      });
      
      // Log activity
      await storage.createActivityLog({
        userId,
        action: "update_personal_info",
        resource: "profile",
        metadata: { firstName, lastName, email },
      });
      
      res.json({ message: "Personal information updated successfully", user: updatedUser });
    } catch (error) {
      console.error("Error updating personal information:", error);
      res.status(500).json({ message: "Failed to update personal information" });
    }
  });

  app.put('/api/profile/access', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const accessSettings = req.body;
      
      // For now, we'll just acknowledge the settings
      // In a real app, you might store these in a user_preferences table
      console.log(`User ${userId} updated access settings:`, accessSettings);
      
      // Log activity
      await storage.createActivityLog({
        userId,
        action: "update_access_settings",
        resource: "profile",
        metadata: { accessSettings },
      });
      
      res.json({ 
        message: "Access settings updated successfully",
        accessSettings 
      });
    } catch (error) {
      console.error("Error updating access settings:", error);
      res.status(500).json({ message: "Failed to update access settings" });
    }
  });

  // Settings routes
  app.get('/api/settings/storage', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      
      // For now, return a default storage setting
      // In a real app, this would fetch from user preferences or system settings
      const storageSettings = {
        storageType: 'local' // default to local storage
      };
      
      res.json(storageSettings);
    } catch (error) {
      console.error("Error fetching storage settings:", error);
      res.status(500).json({ message: "Failed to fetch storage settings" });
    }
  });

  app.put('/api/settings/storage', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { storageType } = req.body;
      
      if (!['local', 'azure', 'aws'].includes(storageType)) {
        return res.status(400).json({ message: "Invalid storage type" });
      }
      
      // In a real app, this would save the setting to database/user preferences
      // For now, we'll just acknowledge the setting
      console.log(`User ${userId} updated storage setting to: ${storageType}`);
      
      // Log activity
      await storage.createActivityLog({
        userId,
        action: "update_storage_settings",
        resource: "settings",
        metadata: { storageType },
      });
      
      res.json({ 
        message: "Storage settings updated successfully",
        storageType 
      });
    } catch (error) {
      console.error("Error updating storage settings:", error);
      res.status(500).json({ message: "Failed to update storage settings" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
