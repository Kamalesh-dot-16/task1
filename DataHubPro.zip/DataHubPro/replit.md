# Defender Pro - Replit.md

## Overview

Defender Pro is an enterprise-grade security and data protection platform with AI/ML capabilities, comprehensive user management, and advanced threat detection features. The application is built with a full-stack TypeScript architecture using React for the frontend, Express for the backend, and PostgreSQL with Drizzle ORM for data persistence.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

The application follows a monorepo structure with clear separation between client, server, and shared components:

- **Frontend**: React with TypeScript, using Vite as the build tool
- **Backend**: Node.js with Express server
- **Database**: PostgreSQL with Drizzle ORM
- **Authentication**: Replit's OpenID Connect authentication system
- **UI Framework**: shadcn/ui components with Tailwind CSS
- **State Management**: TanStack Query for server state management

## Key Components

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Build Tool**: Vite with custom configuration for monorepo support
- **Routing**: Wouter for client-side routing
- **UI Components**: shadcn/ui component library with Radix UI primitives
- **Styling**: Tailwind CSS with custom theme variables
- **State Management**: TanStack Query for API state, React hooks for local state
- **File Structure**: Clean separation with pages, components, hooks, and lib directories

### Backend Architecture
- **Runtime**: Node.js with Express framework
- **Language**: TypeScript with ES modules
- **API Pattern**: RESTful endpoints with consistent error handling
- **Middleware**: Custom logging, JSON parsing, and authentication middleware
- **File Uploads**: Multer for handling multipart form data with 100MB limit
- **Development**: Hot reload with tsx for development server

### Database Layer
- **Database**: PostgreSQL via Neon Database serverless
- **ORM**: Drizzle ORM with full TypeScript support
- **Schema**: Comprehensive schema including users, datasets, processing jobs, insights, reports, notifications, activity logs, and roles
- **Migrations**: Drizzle Kit for schema migrations
- **Connection**: Connection pooling with @neondatabase/serverless

### Authentication System
- **Provider**: Replit OpenID Connect authentication
- **Session Management**: PostgreSQL-backed sessions with connect-pg-simple
- **User Management**: Complete user profile management with role-based access control
- **Security**: HTTP-only cookies, secure session storage, and CSRF protection

## Data Flow

1. **Authentication Flow**: Users authenticate via Replit OIDC, sessions stored in PostgreSQL
2. **Data Upload**: Files uploaded via drag-and-drop interface, stored with metadata in database
3. **Processing Pipeline**: Asynchronous job processing with status tracking and real-time updates
4. **Insights Generation**: AI/ML processing results stored as insights with categorization
5. **Reporting**: Configurable report generation with multiple export formats
6. **Activity Logging**: Comprehensive audit trail for all user actions

## External Dependencies

### Core Dependencies
- **@neondatabase/serverless**: PostgreSQL serverless connection
- **drizzle-orm**: Type-safe database ORM
- **@tanstack/react-query**: Server state management
- **express**: Web framework
- **passport**: Authentication middleware
- **openid-client**: OpenID Connect client

### UI Dependencies
- **@radix-ui/***: Accessible UI primitives
- **tailwindcss**: Utility-first CSS framework
- **class-variance-authority**: Component variant management
- **lucide-react**: Icon library

### Development Dependencies
- **vite**: Build tool and dev server
- **typescript**: Type checking and compilation
- **tsx**: TypeScript execution for development

## Deployment Strategy

### Development Environment
- **Server**: Development server with hot reload using tsx
- **Client**: Vite dev server with HMR and error overlay
- **Database**: Neon PostgreSQL with development connection string
- **Build**: Separate build processes for client (Vite) and server (esbuild)

### Production Build
- **Client Build**: Vite builds to `dist/public` directory
- **Server Build**: esbuild bundles server code to `dist/index.js`
- **Static Assets**: Client assets served by Express in production
- **Environment**: Production mode with optimized builds and error handling

### Key Architectural Decisions

1. **Monorepo Structure**: Simplifies development and deployment while maintaining clear separation of concerns
2. **Drizzle ORM**: Chosen for type safety, performance, and PostgreSQL-first approach
3. **shadcn/ui**: Provides accessible, customizable components with consistent design system
4. **TanStack Query**: Handles complex server state scenarios with caching and synchronization
5. **Replit Auth**: Leverages platform authentication for simplified user management
6. **File Upload Strategy**: Multer with disk storage for handling large datasets up to 100MB
7. **Real-time Updates**: Polling-based approach for processing job status updates

The application is designed for scalability with proper separation of concerns, type safety throughout the stack, and a robust authentication and authorization system suitable for enterprise use.