import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { BarChart3 } from "lucide-react";

export default function ActivityChart() {
  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg font-semibold text-gray-900 dark:text-white">
            Processing Activity
          </CardTitle>
          <Select defaultValue="7days">
            <SelectTrigger className="w-32">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="7days">Last 7 days</SelectItem>
              <SelectItem value="30days">Last 30 days</SelectItem>
              <SelectItem value="90days">Last 90 days</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </CardHeader>
      <CardContent>
        {/* Placeholder for Chart - In a real app, integrate with Chart.js or Recharts */}
        <div className="h-64 bg-gray-50 dark:bg-gray-800 rounded-lg flex items-center justify-center border-2 border-dashed border-gray-300 dark:border-gray-600">
          <div className="text-center">
            <BarChart3 className="text-4xl text-gray-400 mb-2 mx-auto" />
            <p className="text-gray-500 dark:text-gray-400 font-medium">Processing Activity Chart</p>
            <p className="text-sm text-gray-400 dark:text-gray-500 mt-1">Chart visualization will be displayed here</p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
