import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Upload, CheckCircle, Brain, FileText } from "lucide-react";

interface RecentActivityProps {
  activities?: any[];
  isLoading: boolean;
}

export default function RecentActivity({ activities, isLoading }: RecentActivityProps) {
  const getActivityIcon = (action: string) => {
    const iconMap = {
      upload_dataset: Upload,
      processing_complete: CheckCircle,
      generate_insight: Brain,
      generate_report: FileText,
    };
    
    const Icon = iconMap[action as keyof typeof iconMap] || Upload;
    return Icon;
  };

  const getActivityColor = (action: string) => {
    const colorMap = {
      upload_dataset: "bg-primary-blue",
      processing_complete: "bg-green-500",
      generate_insight: "bg-secondary-maroon",
      generate_report: "bg-orange-500",
    };
    
    return colorMap[action as keyof typeof colorMap] || "bg-gray-500";
  };

  const formatActivityMessage = (activity: any) => {
    const actionMap = {
      upload_dataset: `Dataset "${activity.metadata?.fileName || 'file'}" uploaded`,
      processing_complete: "Data processing completed",
      generate_insight: "New insights generated",
      generate_report: "Report generated",
      update_user_role: "User role updated",
      delete_dataset: "Dataset deleted",
    };
    
    return actionMap[activity.action as keyof typeof actionMap] || activity.action;
  };

  const formatTimeAgo = (dateString: string) => {
    const now = new Date();
    const activityDate = new Date(dateString);
    const diffInMinutes = Math.floor((now.getTime() - activityDate.getTime()) / (1000 * 60));
    
    if (diffInMinutes < 1) return "Just now";
    if (diffInMinutes < 60) return `${diffInMinutes} minute${diffInMinutes > 1 ? 's' : ''} ago`;
    
    const diffInHours = Math.floor(diffInMinutes / 60);
    if (diffInHours < 24) return `${diffInHours} hour${diffInHours > 1 ? 's' : ''} ago`;
    
    const diffInDays = Math.floor(diffInHours / 24);
    return `${diffInDays} day${diffInDays > 1 ? 's' : ''} ago`;
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-lg font-semibold text-gray-900 dark:text-white">
          Recent Activity
        </CardTitle>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="space-y-4">
            {[1, 2, 3, 4].map((i) => (
              <div key={i} className="animate-pulse flex items-start space-x-3">
                <div className="w-8 h-8 bg-gray-200 dark:bg-gray-700 rounded-full"></div>
                <div className="flex-1 space-y-1">
                  <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-3/4"></div>
                  <div className="h-3 bg-gray-200 dark:bg-gray-700 rounded w-1/2"></div>
                </div>
              </div>
            ))}
          </div>
        ) : activities && activities.length > 0 ? (
          <div className="space-y-4">
            {activities.slice(0, 4).map((activity) => {
              const Icon = getActivityIcon(activity.action);
              const colorClass = getActivityColor(activity.action);
              
              return (
                <div key={activity.id} className="flex items-start space-x-3">
                  <div className={`w-8 h-8 ${colorClass} rounded-full flex items-center justify-center flex-shrink-0`}>
                    <Icon className="text-white" size={14} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-gray-900 dark:text-white">
                      {formatActivityMessage(activity)}
                    </p>
                    <p className="text-xs text-gray-500 dark:text-gray-400">
                      {formatTimeAgo(activity.createdAt)}
                    </p>
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          <div className="text-center py-6">
            <p className="text-gray-500 dark:text-gray-400">No recent activity</p>
          </div>
        )}
        
        <Button 
          variant="ghost" 
          className="w-full mt-4 text-primary-blue hover:text-blue-600 font-medium"
          onClick={() => window.location.href = "/history"}
        >
          View all activity
        </Button>
      </CardContent>
    </Card>
  );
}
