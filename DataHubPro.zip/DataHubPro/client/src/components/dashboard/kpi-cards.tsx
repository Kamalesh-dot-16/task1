import { Card, CardContent } from "@/components/ui/card";
import { Database, ServerCog, Brain, Cloud } from "lucide-react";

interface KPICardsProps {
  metrics?: {
    totalDatasets: number;
    activeJobs: number;
    totalInsights: number;
    storageUsed: string;
  };
  isLoading: boolean;
}

export default function KPICards({ metrics, isLoading }: KPICardsProps) {
  if (isLoading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {[1, 2, 3, 4].map((i) => (
          <Card key={i} className="animate-pulse">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div className="space-y-2">
                  <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-24"></div>
                  <div className="h-8 bg-gray-200 dark:bg-gray-700 rounded w-16"></div>
                </div>
                <div className="w-12 h-12 bg-gray-200 dark:bg-gray-700 rounded-lg"></div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  const kpiData = [
    {
      title: "Total Audited",
      value: metrics?.totalDatasets || 0,
      icon: Database,
      color: "text-primary-blue",
      bgColor: "bg-primary-blue bg-opacity-10",
      change: "+12%",
      changeLabel: "from last month",
    },
    {
      title: "Processing Jobs",
      value: metrics?.activeJobs || 0,
      icon: ServerCog,
      color: "text-secondary-maroon",
      bgColor: "bg-secondary-maroon bg-opacity-10",
      change: `${metrics?.activeJobs || 0} active`,
      changeLabel: "currently running",
    },
    {
      title: "Insights Generated",
      value: metrics?.totalInsights || 0,
      icon: Brain,
      color: "text-green-500",
      bgColor: "bg-green-500 bg-opacity-10",
      change: "+8",
      changeLabel: "this week",
    },
    {
      title: "Storage Used",
      value: metrics?.storageUsed || "0 GB",
      icon: Cloud,
      color: "text-orange-500",
      bgColor: "bg-orange-500 bg-opacity-10",
      change: "",
      changeLabel: "of allocated space",
    },
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
      {kpiData.map((kpi) => {
        const Icon = kpi.icon;
        return (
          <Card key={kpi.title}>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600 dark:text-gray-400">{kpi.title}</p>
                  <p className="text-3xl font-bold text-gray-900 dark:text-white">{kpi.value}</p>
                </div>
                <div className={`w-12 h-12 ${kpi.bgColor} rounded-lg flex items-center justify-center`}>
                  <Icon className={`${kpi.color} text-xl`} size={24} />
                </div>
              </div>
              {(kpi.change || kpi.changeLabel) && (
                <div className="mt-4 flex items-center">
                  {kpi.change && (
                    <span className={`text-sm font-medium ${
                      kpi.change.startsWith('+') ? 'text-green-500' : 
                      kpi.change.includes('active') ? 'text-blue-500' : 'text-gray-500'
                    }`}>
                      {kpi.change}
                    </span>
                  )}
                  {kpi.changeLabel && (
                    <span className="text-gray-500 dark:text-gray-400 text-sm ml-2">{kpi.changeLabel}</span>
                  )}
                </div>
              )}
            </CardContent>
          </Card>
        );
      })}
    </div>
  );
}
