import { useState } from "react";
import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/useAuth";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";
import { 
  ChartLine, 
  Upload, 
  Database, 
  Brain, 
  FileText, 
  History, 
  Users, 
  Shield,
  Settings,
  ChevronLeft,
  ChevronRight
} from "lucide-react";

const navigation = [
  { name: "Dashboard", href: "/", icon: ChartLine },
  { name: "Data Upload", href: "/data-upload", icon: Upload },
  { name: "Data Processing", href: "/data-processing", icon: Database },
  { name: "AI Insights", href: "/insights", icon: Brain },
  { name: "Reports", href: "/reports", icon: FileText },
  { name: "History", href: "/history", icon: History },
  { name: "Settings", href: "/settings", icon: Settings },
];

const adminNavigation = [
  { name: "User Management", href: "/user-management", icon: Users },
  { name: "Role Management", href: "/role-management", icon: Shield },
];

interface SidebarProps {
  isCollapsed: boolean;
  setIsCollapsed: (collapsed: boolean) => void;
}

export default function Sidebar({ isCollapsed, setIsCollapsed }: SidebarProps) {
  const [location] = useLocation();
  const { user } = useAuth();

  const isAdmin = (user as any)?.role === "admin";

  return (
    <>
      <div className={cn(
        "fixed inset-y-0 left-0 bg-white dark:bg-gray-800 shadow-lg border-r border-gray-200 dark:border-gray-700 z-40 transition-all duration-300",
        isCollapsed ? "w-16" : "w-64"
      )}>
        <div className="flex items-center justify-center h-16 px-4 border-b border-gray-200 dark:border-gray-700">
          <div className="flex items-center">
            <div className={cn(
              "w-8 h-8 bg-primary-blue rounded-lg flex items-center justify-center",
              isCollapsed ? "" : "mr-2"
            )}>
              <ChartLine className="text-white text-sm" />
            </div>
            {!isCollapsed && (
              <span className="text-xl font-bold text-gray-900 dark:text-white">Defender Pro</span>
            )}
          </div>
        </div>
      
        <nav className="mt-8 px-4">
          <div className="space-y-2">
            {navigation.map((item) => {
              const Icon = item.icon;
              const isActive = location === item.href;
              
              if (isCollapsed) {
                return (
                  <Tooltip key={item.name}>
                    <TooltipTrigger asChild>
                      <Link href={item.href}>
                        <a className={cn(
                          "sidebar-nav-collapsed",
                          isActive && "active"
                        )}>
                          <Icon size={18} />
                        </a>
                      </Link>
                    </TooltipTrigger>
                    <TooltipContent side="right">
                      <p>{item.name}</p>
                    </TooltipContent>
                  </Tooltip>
                );
              }
              
              return (
                <Link key={item.name} href={item.href}>
                  <a className={cn(
                    "sidebar-nav",
                    isActive && "active"
                  )}>
                    <Icon className="mr-3" size={18} />
                    {item.name}
                  </a>
                </Link>
              );
            })}
          </div>

          {/* Admin Section */}
          {isAdmin && (
            <div className="mt-8 pt-8 border-t border-gray-200 dark:border-gray-700">
              {!isCollapsed && (
                <p className="px-4 text-xs font-semibold text-gray-400 uppercase tracking-wider mb-2">
                  Administration
                </p>
              )}
              <div className="space-y-2">
                {adminNavigation.map((item) => {
                  const Icon = item.icon;
                  const isActive = location === item.href;
                  
                  if (isCollapsed) {
                    return (
                      <Tooltip key={item.name}>
                        <TooltipTrigger asChild>
                          <Link href={item.href}>
                            <a className={cn(
                              "sidebar-nav-collapsed",
                              isActive && "active"
                            )}>
                              <Icon size={18} />
                            </a>
                          </Link>
                        </TooltipTrigger>
                        <TooltipContent side="right">
                          <p>{item.name}</p>
                        </TooltipContent>
                      </Tooltip>
                    );
                  }
                  
                  return (
                    <Link key={item.name} href={item.href}>
                      <a className={cn(
                        "sidebar-nav",
                        isActive && "active"
                      )}>
                        <Icon className="mr-3" size={18} />
                        {item.name}
                      </a>
                    </Link>
                  );
                })}
              </div>
            </div>
          )}
        </nav>
      </div>

      {/* Toggle Button */}
      <Button
        variant="outline"
        size="sm"
        className={cn(
          "fixed top-1/2 -translate-y-1/2 z-50 w-8 h-8 rounded-full p-0 bg-white dark:bg-gray-800 border-2 border-gray-200 dark:border-gray-700 shadow-md hover:shadow-lg transition-all duration-300",
          isCollapsed ? "left-12" : "left-60"
        )}
        onClick={() => setIsCollapsed(!isCollapsed)}
      >
        {isCollapsed ? (
          <ChevronRight size={14} />
        ) : (
          <ChevronLeft size={14} />
        )}
      </Button>
    </>
  );
}
