import { useCallback, useState } from "react";
import { useDropzone } from "react-dropzone";
import { Card } from "@/components/ui/card";
import { Upload, FileText, Image, Video, X } from "lucide-react";

interface FileDropzoneProps {
  onFilesSelected: (files: File[]) => void;
}

export default function FileDropzone({ onFilesSelected }: FileDropzoneProps) {
  const [isDragActive, setIsDragActive] = useState(false);

  const onDrop = useCallback((acceptedFiles: File[]) => {
    onFilesSelected(acceptedFiles);
    setIsDragActive(false);
  }, [onFilesSelected]);

  const { getRootProps, getInputProps } = useDropzone({
    onDrop,
    onDragEnter: () => setIsDragActive(true),
    onDragLeave: () => setIsDragActive(false),
    accept: {
      // Text files
      'text/csv': ['.csv'],
      'text/plain': ['.txt'],
      'application/json': ['.json'],
      'application/xml': ['.xml'],
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': ['.xlsx'],
      'application/vnd.ms-excel': ['.xls'],
      'application/pdf': ['.pdf'],
      
      // Image files
      'image/jpeg': ['.jpg', '.jpeg'],
      'image/png': ['.png'],
      'image/gif': ['.gif'],
      'image/webp': ['.webp'],
      'image/svg+xml': ['.svg'],
      'image/bmp': ['.bmp'],
      
      // Video files
      'video/mp4': ['.mp4'],
      'video/avi': ['.avi'],
      'video/quicktime': ['.mov'],
      'video/x-ms-wmv': ['.wmv'],
      'video/x-flv': ['.flv'],
      'video/webm': ['.webm'],
      'video/x-matroska': ['.mkv'],
    },
    multiple: true,
    maxSize: 100 * 1024 * 1024, // 100MB limit
  });

  return (
    <Card
      {...getRootProps()}
      className={`relative border-2 border-dashed p-8 text-center cursor-pointer transition-colors ${
        isDragActive
          ? "border-primary-blue bg-blue-50 dark:bg-blue-900/20"
          : "border-gray-300 dark:border-gray-600 hover:border-primary-blue hover:bg-gray-50 dark:hover:bg-gray-800"
      }`}
    >
      <input {...getInputProps()} />
      
      <div className="flex flex-col items-center space-y-4">
        <div className="flex items-center space-x-2 text-gray-400">
          <Upload size={24} />
          <FileText size={24} />
          <Image size={24} />
          <Video size={24} />
        </div>
        
        <div>
          <p className="text-lg font-medium text-gray-900 dark:text-white">
            Drop your files here, or click to browse
          </p>
          <p className="text-sm text-gray-500 dark:text-gray-400 mt-2">
            Supports text files (CSV, JSON, TXT, PDF), images (JPG, PNG, GIF), and videos (MP4, AVI, MOV)
          </p>
          <p className="text-xs text-gray-400 mt-1">
            Maximum file size: 100MB per file
          </p>
        </div>
        
        {isDragActive && (
          <div className="absolute inset-0 bg-primary-blue/10 border-2 border-primary-blue border-dashed rounded-lg flex items-center justify-center">
            <p className="text-primary-blue font-medium">Drop files to upload</p>
          </div>
        )}
      </div>
    </Card>
  );
}