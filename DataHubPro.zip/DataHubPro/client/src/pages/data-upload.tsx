import { useEffect, useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { isUnauthorizedError } from "@/lib/authUtils";
import { apiRequest } from "@/lib/queryClient";
import Sidebar from "@/components/layout/sidebar";
import TopBar from "@/components/layout/topbar";
import FileDropzone from "@/components/upload/file-dropzone";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { FileText, Trash2, Eye, X } from "lucide-react";

export default function DataUpload() {
  const { toast } = useToast();
  const { isAuthenticated, isLoading } = useAuth();
  const queryClient = useQueryClient();
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  
  const [selectedFiles, setSelectedFiles] = useState<File[]>([]);
  const [uploadOptions, setUploadOptions] = useState({
    name: "",
    category: "text", // text, image, video
    description: "",
    autoValidate: false,
    generatePreview: false,
    startAnalysis: false,
  });

  // Redirect if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  const { data: datasets = [], isLoading: datasetsLoading } = useQuery<any[]>({
    queryKey: ["/api/datasets"],
    retry: false,
  });

  const uploadMutation = useMutation({
    mutationFn: async (formData: FormData) => {
      return await apiRequest("POST", "/api/datasets", formData);
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Dataset uploaded successfully!",
      });
      setSelectedFiles([]);
      setUploadOptions({
        name: "",
        category: "Sales Data",
        description: "",
        autoValidate: false,
        generatePreview: false,
        startAnalysis: false,
      });
      queryClient.invalidateQueries({ queryKey: ["/api/datasets"] });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Upload Failed",
        description: error.message || "Failed to upload dataset",
        variant: "destructive",
      });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      return await apiRequest("DELETE", `/api/datasets/${id}`);
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Dataset deleted successfully!",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/datasets"] });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Delete Failed",
        description: error.message || "Failed to delete dataset",
        variant: "destructive",
      });
    },
  });

  const handleFilesSelected = (files: File[]) => {
    setSelectedFiles(prev => [...prev, ...files]);
    if (files.length === 1 && !uploadOptions.name) {
      setUploadOptions(prev => ({
        ...prev,
        name: files[0].name.replace(/\.[^/.]+$/, "")
      }));
    }
  };

  const removeFile = (index: number) => {
    setSelectedFiles(prev => prev.filter((_, i) => i !== index));
  };

  const handleUpload = async () => {
    if (selectedFiles.length === 0) {
      toast({
        title: "No files selected",
        description: "Please select files to upload",
        variant: "destructive",
      });
      return;
    }

    if (!uploadOptions.name.trim()) {
      toast({
        title: "Dataset name required",
        description: "Please enter a dataset name",
        variant: "destructive",
      });
      return;
    }

    // For now, upload the first file (extend for multiple files)
    const formData = new FormData();
    formData.append('file', selectedFiles[0]);
    formData.append('name', uploadOptions.name);
    formData.append('category', uploadOptions.category);
    formData.append('description', uploadOptions.description);

    uploadMutation.mutate(formData);
  };

  const getStatusBadge = (status: string) => {
    const variants = {
      completed: "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300",
      processing: "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300",
      failed: "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300",
      uploaded: "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300",
    };
    
    return (
      <Badge className={variants[status as keyof typeof variants] || variants.uploaded}>
        {status.charAt(0).toUpperCase() + status.slice(1)}
      </Badge>
    );
  };

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const getFileIcon = (fileName: string) => {
    const extension = fileName.split('.').pop()?.toLowerCase();
    
    // Image files
    if (['jpg', 'jpeg', 'png', 'gif', 'webp', 'svg', 'bmp'].includes(extension || '')) {
      return <FileText className="text-purple-500" size={20} />;
    }
    
    // Video files
    if (['mp4', 'avi', 'mov', 'wmv', 'flv', 'webm', 'mkv'].includes(extension || '')) {
      return <FileText className="text-red-500" size={20} />;
    }
    
    // Text/Data files
    const iconClass: Record<string, string> = {
      'csv': 'text-green-500',
      'xlsx': 'text-green-600',
      'xls': 'text-green-600',
      'json': 'text-blue-500',
      'xml': 'text-orange-500',
      'txt': 'text-gray-600',
      'pdf': 'text-red-600',
    };
    
    return <FileText className={iconClass[extension || ''] || 'text-gray-500'} size={20} />;
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-blue"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <Sidebar isCollapsed={sidebarCollapsed} setIsCollapsed={setSidebarCollapsed} />
      
      <div className={sidebarCollapsed ? "ml-16" : "ml-64"} style={{ transition: "margin-left 300ms" }}>
        <TopBar title="Data Upload" />
        
        <div className="p-6 max-w-4xl">
          {/* Upload Area */}
          <Card className="mb-6">
            <CardHeader>
              <CardTitle>Upload Data Files</CardTitle>
            </CardHeader>
            <CardContent>
              <FileDropzone onFilesSelected={handleFilesSelected} />
              
              {selectedFiles.length > 0 && (
                <div className="mt-4">
                  <h4 className="font-medium mb-2">Selected Files:</h4>
                  <div className="space-y-2">
                    {selectedFiles.map((file, index) => (
                      <div key={index} className="flex items-center justify-between p-2 bg-gray-50 dark:bg-gray-800 rounded-md">
                        <div className="flex items-center space-x-2">
                          {getFileIcon(file.name)}
                          <span className="text-sm font-medium">{file.name}</span>
                          <span className="text-xs text-gray-500">({formatFileSize(file.size)})</span>
                        </div>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => removeFile(index)}
                        >
                          <X size={16} />
                        </Button>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Upload Options */}
          <Card className="mb-6">
            <CardHeader>
              <CardTitle>Upload Options</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="batch-name">Batch Name</Label>
                  <Input
                    id="batch-name"
                    value={uploadOptions.name}
                    onChange={(e) => setUploadOptions(prev => ({ ...prev, name: e.target.value }))}
                    placeholder="Enter batch name"
                  />
                </div>
                
                <div>
                  <Label htmlFor="category">Category</Label>
                  <Select
                    value={uploadOptions.category}
                    onValueChange={(value) => setUploadOptions(prev => ({ ...prev, category: value }))}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="text">Text Files (CSV, JSON, TXT, etc.)</SelectItem>
                      <SelectItem value="image">Image Files (JPG, PNG, GIF, etc.)</SelectItem>
                      <SelectItem value="video">Video Files (MP4, AVI, MOV, etc.)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="md:col-span-2">
                  <Label htmlFor="description">Description</Label>
                  <Textarea
                    id="description"
                    value={uploadOptions.description}
                    onChange={(e) => setUploadOptions(prev => ({ ...prev, description: e.target.value }))}
                    placeholder="Brief description of the dataset"
                    rows={3}
                  />
                </div>
                
                <div className="md:col-span-2 space-y-2">
                  <Label>Processing Options</Label>
                  <div className="space-y-2">
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="auto-validate"
                        checked={uploadOptions.autoValidate}
                        onCheckedChange={(checked) => 
                          setUploadOptions(prev => ({ ...prev, autoValidate: checked as boolean }))
                        }
                      />
                      <Label htmlFor="auto-validate" className="text-sm">Auto-validate data quality</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="generate-preview"
                        checked={uploadOptions.generatePreview}
                        onCheckedChange={(checked) => 
                          setUploadOptions(prev => ({ ...prev, generatePreview: checked as boolean }))
                        }
                      />
                      <Label htmlFor="generate-preview" className="text-sm">Generate preview</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="start-analysis"
                        checked={uploadOptions.startAnalysis}
                        onCheckedChange={(checked) => 
                          setUploadOptions(prev => ({ ...prev, startAnalysis: checked as boolean }))
                        }
                      />
                      <Label htmlFor="start-analysis" className="text-sm">Start AI analysis</Label>
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="mt-6">
                <Button 
                  onClick={handleUpload}
                  disabled={uploadMutation.isPending || selectedFiles.length === 0}
                  className="bg-primary-blue hover:bg-blue-600"
                >
                  {uploadMutation.isPending ? "Uploading..." : "Upload Dataset"}
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Recent Uploads */}
          <Card>
            <CardHeader>
              <CardTitle>Recent Uploads</CardTitle>
            </CardHeader>
            <CardContent>
              {datasetsLoading ? (
                <div className="flex items-center justify-center py-8">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary-blue"></div>
                </div>
              ) : datasets && datasets.length > 0 ? (
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead className="bg-gray-50 dark:bg-gray-800">
                      <tr>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">File Name</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">Size</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">Status</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">Uploaded</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="bg-white dark:bg-gray-900 divide-y divide-gray-200 dark:divide-gray-700">
                      {datasets.map((dataset: any) => (
                        <tr key={dataset.id}>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="flex items-center">
                              {getFileIcon(dataset.fileName)}
                              <span className="ml-3 text-sm font-medium text-gray-900 dark:text-white">
                                {dataset.fileName}
                              </span>
                            </div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400">
                            {formatFileSize(dataset.fileSize)}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            {getStatusBadge(dataset.status)}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400">
                            {new Date(dataset.createdAt).toLocaleDateString()}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                            <Button variant="ghost" size="sm" className="mr-2">
                              <Eye size={16} className="mr-1" />
                              View
                            </Button>
                            <Button 
                              variant="ghost" 
                              size="sm"
                              className="text-red-600 hover:text-red-700"
                              onClick={() => deleteMutation.mutate(dataset.id)}
                              disabled={deleteMutation.isPending}
                            >
                              <Trash2 size={16} className="mr-1" />
                              Delete
                            </Button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              ) : (
                <div className="text-center py-8">
                  <p className="text-gray-500 dark:text-gray-400">No datasets uploaded yet.</p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
