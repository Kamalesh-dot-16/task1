import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { ChartLine, Upload, Brain, Users, Shield, FileText } from "lucide-react";

export default function Landing() {
  const handleLogin = () => {
    window.location.href = "/api/login";
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-red-50 dark:from-gray-900 dark:via-gray-800 dark:to-gray-900">
      <div className="container mx-auto px-4 py-16">
        {/* Hero Section */}
        <div className="text-center mb-16">
          <div className="flex items-center justify-center mb-6">
            <div className="w-16 h-16 bg-primary-blue rounded-lg flex items-center justify-center mr-4">
              <ChartLine className="text-white text-2xl" />
            </div>
            <h1 className="text-4xl font-bold text-gray-900 dark:text-white">Defender Pro</h1>
          </div>
          <p className="text-xl text-gray-600 dark:text-gray-300 mb-8 max-w-2xl mx-auto">
            Enterprise Security & Data Protection Platform with AI/ML capabilities, comprehensive user management, 
            and advanced threat detection features.
          </p>
          <Button 
            onClick={handleLogin}
            size="lg"
            className="bg-primary-blue hover:bg-blue-600 text-white px-8 py-3 text-lg"
          >
            Get Started
          </Button>
        </div>

        {/* Features Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
          <Card className="border-0 shadow-lg hover:shadow-xl transition-shadow">
            <CardContent className="p-6 text-center">
              <div className="w-12 h-12 bg-primary-blue bg-opacity-10 rounded-lg flex items-center justify-center mx-auto mb-4">
                <Upload className="text-primary-blue text-xl" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">Secure Data Upload & Analysis</h3>
              <p className="text-gray-600 dark:text-gray-300">
                Upload and analyze security data including logs, threat intelligence, and compliance reports.
              </p>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-lg hover:shadow-xl transition-shadow">
            <CardContent className="p-6 text-center">
              <div className="w-12 h-12 bg-secondary-maroon bg-opacity-10 rounded-lg flex items-center justify-center mx-auto mb-4">
                <Brain className="text-secondary-maroon text-xl" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">AI-Powered Threat Detection</h3>
              <p className="text-gray-600 dark:text-gray-300">
                Detect and analyze security threats using advanced AI/ML algorithms and behavioral analysis.
              </p>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-lg hover:shadow-xl transition-shadow">
            <CardContent className="p-6 text-center">
              <div className="w-12 h-12 bg-green-500 bg-opacity-10 rounded-lg flex items-center justify-center mx-auto mb-4">
                <FileText className="text-green-500 text-xl" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">Security Reports & Compliance</h3>
              <p className="text-gray-600 dark:text-gray-300">
                Generate compliance reports and security assessments with export capabilities in multiple formats.
              </p>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-lg hover:shadow-xl transition-shadow">
            <CardContent className="p-6 text-center">
              <div className="w-12 h-12 bg-purple-500 bg-opacity-10 rounded-lg flex items-center justify-center mx-auto mb-4">
                <Users className="text-purple-500 text-xl" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">User Management</h3>
              <p className="text-gray-600 dark:text-gray-300">
                Comprehensive user management system with role-based access control and permissions.
              </p>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-lg hover:shadow-xl transition-shadow">
            <CardContent className="p-6 text-center">
              <div className="w-12 h-12 bg-orange-500 bg-opacity-10 rounded-lg flex items-center justify-center mx-auto mb-4">
                <Shield className="text-orange-500 text-xl" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">Enterprise Security</h3>
              <p className="text-gray-600 dark:text-gray-300">
                Secure authentication, role-based permissions, and comprehensive activity logging.
              </p>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-lg hover:shadow-xl transition-shadow">
            <CardContent className="p-6 text-center">
              <div className="w-12 h-12 bg-cyan-500 bg-opacity-10 rounded-lg flex items-center justify-center mx-auto mb-4">
                <ChartLine className="text-cyan-500 text-xl" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">Security Dashboard</h3>
              <p className="text-gray-600 dark:text-gray-300">
                Monitor security events, threat detection activities, and system health with real-time dashboards.
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Demo Credentials */}
        <Card className="max-w-md mx-auto border border-gray-200 dark:border-gray-700">
          <CardContent className="p-6 text-center">
            <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">Demo Access</h3>
            <p className="text-sm text-gray-600 dark:text-gray-300 mb-4">
              Click "Get Started" above to begin the authentication process with Replit Auth.
            </p>
            <Button 
              onClick={handleLogin}
              className="w-full bg-primary-blue hover:bg-blue-600 text-white"
            >
              Sign In with Replit
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
